package com.example.mushasha

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.mushasha.DashboardActivity

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
    }
}distributionUrl=https\://services.gradle.org/distributions/gradle-7.5-bin.zip