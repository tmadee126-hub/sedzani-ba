package com.example.mushasha

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.mushasha.data.database.AppDatabase
import com.example.mushasha.data.database.User
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val loginBtn = findViewById<Button>(R.id.loginBtn)

        val db = AppDatabase.getDatabase(this)

        loginBtn.setOnClickListener {
            lifecycleScope.launch {
                val user = db.userDao().login(
                    username.text.toString(),
                    password.text.toString()
                )

                if (user != null) {
                    startActivity(Intent(this@MainActivity, DashboardActivity::class.java))
                } else {
                    db.userDao().insert(
                        User(username = username.text.toString(), password = password.text.toString())
                    )
                    Toast.makeText(this@MainActivity, "User created!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}