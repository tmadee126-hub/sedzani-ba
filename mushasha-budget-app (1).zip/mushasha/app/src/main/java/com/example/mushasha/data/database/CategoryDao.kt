package com.example.mushasha.data.database

import androidx.room.*

@Dao
interface CategoryDao {

    @Insert
    suspend fun insert(category: Category)

    @Query("SELECT * FROM Category")
    suspend fun getAll(): List<Category>
}